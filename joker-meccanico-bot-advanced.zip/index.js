
require('dotenv').config();
const {
    Client,
    GatewayIntentBits,
    SlashCommandBuilder,
    REST,
    Routes,
    ChannelType,
    PermissionsBitField,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder
} = require('discord.js');

const express = require("express");
const app = express();

app.get("/", (req, res) => res.send("Bot Online"));
app.listen(3000);

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

const RUOLO_ID = "1474463924870058024";
const CATEGORIA_ID = "1474463973062606922";
const CLASSIFICA_ID = "1478886552187961468";
const PANNELLO_ID = "1478885140938883193";

let utenti = {};
let inServizio = new Set();

client.once("ready", async () => {
    console.log("JOKER BOT ONLINE");

    const channel = await client.channels.fetch(PANNELLO_ID);

    const embed = new EmbedBuilder()
        .setTitle("💰 Pannello Servizio Meccanici")
        .setDescription("Premi il bottone per entrare o uscire dal servizio");

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("entra_servizio")
            .setLabel("🔧 Entra in Servizio")
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId("esci_servizio")
            .setLabel("❌ Esci dal Servizio")
            .setStyle(ButtonStyle.Danger)
    );

    await channel.send({ embeds: [embed], components: [row] });
});

const commands = [
    new SlashCommandBuilder()
        .setName("fattura")
        .setDescription("Registra una fattura")
        .addStringOption(o =>
            o.setName("tipo")
             .setDescription("patente / riparazione / altro")
             .setRequired(true))
        .addIntegerOption(o =>
            o.setName("prezzo")
             .setDescription("Prezzo")
             .setRequired(true))
].map(c => c.toJSON());

const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);

(async () => {
    await rest.put(
        Routes.applicationGuildCommands("1432354048325189757", "1473648022524133523"),
        { body: commands }
    );
})();

client.on("interactionCreate", async interaction => {

    if (interaction.isButton()) {
        if (!interaction.member.roles.cache.has(RUOLO_ID))
            return interaction.reply({ content: "Non sei Meccanico", ephemeral: true });

        if (interaction.customId === "entra_servizio") {
            inServizio.add(interaction.user.id);
            return interaction.reply({ content: "✅ Sei in servizio", ephemeral: true });
        }

        if (interaction.customId === "esci_servizio") {
            inServizio.delete(interaction.user.id);
            return interaction.reply({ content: "❌ Sei uscito dal servizio", ephemeral: true });
        }
    }

    if (!interaction.isChatInputCommand()) return;

    if (!interaction.member.roles.cache.has(RUOLO_ID))
        return interaction.reply({ content: "Non sei Meccanico", ephemeral: true });

    if (!inServizio.has(interaction.user.id))
        return interaction.reply({ content: "Devi essere in servizio!", ephemeral: true });

    const userId = interaction.user.id;

    if (!utenti[userId]) {
        utenti[userId] = { fatture: 0, totale: 0, canaleId: null };
    }

    if (interaction.commandName === "fattura") {
        const tipo = interaction.options.getString("tipo");
        const prezzo = interaction.options.getInteger("prezzo");

        utenti[userId].fatture++;
        utenti[userId].totale += prezzo;

        if (!utenti[userId].canaleId) {
            const canale = await interaction.guild.channels.create({
                name: `💰ᴊᴏᴋᴇʀ-${interaction.user.username}`,
                type: ChannelType.GuildText,
                parent: CATEGORIA_ID,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionsBitField.Flags.ViewChannel],
                    },
                    {
                        id: userId,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                    }
                ]
            });
            utenti[userId].canaleId = canale.id;
        }

        const canale = await client.channels.fetch(utenti[userId].canaleId);

        await canale.send(
            `🧾 Fattura
Tipo: ${tipo}
Prezzo: ${prezzo}$

📊 Totale Fatture: ${utenti[userId].fatture}
💰 Totale Guadagni: ${utenti[userId].totale}$`
        );

        interaction.reply({ content: "Fattura registrata!", ephemeral: true });
    }
});

setInterval(async () => {
    let arr = Object.entries(utenti)
        .map(([id, data]) => ({ id, ...data }))
        .sort((a, b) => b.fatture - a.fatture);

    let testo = "🏆 Classifica Giornaliera Meccanici\n\n";
    arr.forEach((u, i) => {
        testo += `${i + 1}. <@${u.id}> - ${u.fatture} fatture - ${u.totale}$\n`;
    });

    const channel = await client.channels.fetch(CLASSIFICA_ID);
    await channel.send(testo);

    utenti = {};
}, 86400000);

client.login(process.env.TOKEN);
