HOST CONSIGLIATO: Railway

1) Carica cartella su GitHub
2) Vai su railway.app
3) New Project -> Deploy from GitHub
4) Settings -> Variables -> aggiungi TOKEN
5) Deploy

NON condividere mai il token.
